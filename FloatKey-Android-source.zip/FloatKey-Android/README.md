# FloatKey Android (prototype)

A minimal native Android keyboard prototype with:
- A basic InputMethodService keyboard
- A movable floating `FK` button
- GitHub Actions workflow to build a debug APK

## Important limitations
This is an early prototype, not a polished or verified release. The floating bubble opens Android's keyboard picker; it does not force the keyboard to appear over every app. Keyboard visibility depends on Android focus and the app being used. The current `?123` and shift keys are placeholders. Test carefully before relying on it in games.

## Build
Push this project to the `main` branch. GitHub Actions builds a debug APK and uploads it as the `FloatKey-debug-apk` artifact. Open the repository's Actions tab, choose the latest successful run, then download the artifact.

## Permissions and setup on device
1. Install the APK.
2. Open FloatKey and enable it under Android keyboard settings.
3. Select FloatKey from the keyboard picker when an editable text field is focused.
4. Grant "Display over other apps" permission to use the floating bubble.
