package com.floatkey

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }
        val title = TextView(this).apply {
            text = "FloatKey"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Lightweight keyboard prototype\\n\\n1. Enable FloatKey in keyboard settings.\\n2. Select FloatKey as your keyboard.\\n3. Allow overlay permission to show the floating button."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 20)
        }
        val enable = Button(this).apply {
            text = "Enable FloatKey keyboard"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }
        val choose = Button(this).apply {
            text = "Choose keyboard"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showInputMethodPicker()
            }
        }
        val overlay = Button(this).apply {
            text = "Allow floating button"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName"))
                    )
                } else {
                    startService(Intent(this@MainActivity, FloatingService::class.java))
                }
            }
        }
        val start = Button(this).apply {
            text = "Start floating button"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, FloatingService::class.java))
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(enable)
        layout.addView(choose)
        layout.addView(overlay)
        layout.addView(start)
        setContentView(layout)
    }
}
