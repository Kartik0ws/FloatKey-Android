package com.floatkey

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout

class FloatInputMethodService : InputMethodService() {
    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 6, 4, 6)
            setBackgroundColor(Color.rgb(28, 30, 36))
        }

        fun addRow(keys: List<String>) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            keys.forEach { key ->
                val button = Button(this).apply {
                    text = key
                    isAllCaps = false
                    textSize = 16f
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(0, 0, 0, 0)
                    val params = LinearLayout.LayoutParams(0, 48, 1f)
                    params.setMargins(2, 2, 2, 2)
                    layoutParams = params
                    setOnClickListener { handleKey(key) }
                }
                row.addView(button)
            }
            root.addView(row)
        }

        addRow(listOf("1","2","3","4","5","6","7","8","9","0"))
        addRow(listOf("q","w","e","r","t","y","u","i","o","p"))
        addRow(listOf("a","s","d","f","g","h","j","k","l"))
        addRow(listOf("⇧","z","x","c","v","b","n","m","⌫"))
        addRow(listOf("?123",",","😊","space",".","↵"))
        return root
    }

    private fun handleKey(key: String) {
        val ic: InputConnection = currentInputConnection ?: return
        when (key) {
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "↵" -> ic.commitText("\n", 1)
            "space" -> ic.commitText(" ", 1)
            "?123" -> { /* numeric layout can be added in a later version */ }
            "⇧" -> { /* shift toggle can be added in a later version */ }
            "😊" -> ic.commitText("😊", 1)
            else -> ic.commitText(key, 1)
        }
    }
}
